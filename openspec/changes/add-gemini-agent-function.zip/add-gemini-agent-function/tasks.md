## 1. Shared Backend Foundations

- [ ] 1.1 Audit `generate-image` and `_shared` modules to identify the Gemini image generation logic that must be reused by both `generate-image` and `agent`
- [ ] 1.2 Extract shared Gemini image generation utilities under `supabase/functions/_shared/` for provider resolution, reference-image preparation, asset upload, and normalized error handling, keeping points deduction and job lifecycle outside the shared core
- [ ] 1.3 Refactor `supabase/functions/generate-image/index.ts` to use the extracted shared image generation core without changing the existing jobs-based contract or current image-model billing behavior
- [ ] 1.4 Add or update shared backend tests covering the extracted Gemini image generation utilities and preserving the current `generate-image` output contract

## 2. Agent Data Model And Pricing

- [ ] 2.1 Add a Supabase migration for the `agent_sessions` table keyed by `conversation_id` with `history` JSONB and `updated_at` columns
- [ ] 2.2 Add the required RLS / access policy setup so `agent_sessions` is only accessed from server-side execution paths
- [ ] 2.3 Add or update `ai_models` seed data, schema, and related queries so Agent mode has a dedicated system model entry for pricing and display while remaining hidden from the classic `ModelSelector` (for example via an `is_agent_only` flag or equivalent)
- [ ] 2.4 Add migration and query tests covering `agent_sessions` schema expectations, Agent model pricing lookup behavior, and exclusion of Agent-only models from classic selector queries

## 3. Agent Edge Function

- [ ] 3.1 Create `supabase/functions/agent/index.ts` with request validation for `projectId`, `documentId`, `conversationId`, `prompt`, and optional `aspectRatio`, `resolution`, `referenceImageUrl`
- [ ] 3.2 Implement authentication, project / document / conversation ownership checks, cross-entity consistency validation, and trusted reference image URL validation in the Agent Edge Function
- [ ] 3.3 Implement the Gemini reasoning loop with a maximum iteration limit, SSE streaming, and retry behavior for transient model failures
- [ ] 3.4 Implement `generate_image` tool execution in the Agent function by reusing the extracted shared Gemini image generation core without triggering a second image-model points deduction after the request-level Agent charge
- [ ] 3.5 Implement `agent_sessions` history load, bootstrap-from-messages for the first Agent turn in an existing conversation, truncate, and save behavior around each successful Agent turn
- [ ] 3.6 Persist each successful Agent assistant turn into the existing `messages` table with `mode`, `modelName`, optional `thinking`, and generated image references needed for reload/realtime rendering
- [ ] 3.7 Add Edge Function tests for validation errors, authorization failures, SSE event ordering, no-double-charge tool execution, history persistence, assistant message persistence, and insufficient points handling

## 4. Chat Mode State And UI

- [ ] 4.1 Extend `useChatStore` with `chatMode`, `setChatMode`, and persistence logic while preserving the existing classic-mode selected model state
- [ ] 4.2 Add a mode selector component in `src/components/chat/ChatInput.tsx` for `classic`, `agent`, and `image-generator`
- [ ] 4.3 Update ChatInput toolbar visibility rules so classic mode keeps current controls while Agent and Image Generator show only the intended controls
- [ ] 4.4 Add or update i18n strings and UI tests for the new chat modes, labels, mode persistence behavior, and the absence of Agent-only models from the classic selector

## 5. Frontend Generation Routing

- [ ] 5.1 Extend `src/lib/api/generate.ts` with an Agent SSE client that authenticates correctly, parses streamed events, and exposes the persisted final message payload carried by the `done` event
- [ ] 5.2 Add Agent-mode generation flow in `src/hooks/chat/useGeneration.ts` and/or a dedicated hook for SSE lifecycle, partial assistant text, tool status, abort, and pending-message replacement using the backend-persisted final message payload
- [ ] 5.3 Update `src/components/chat/ChatPanel.tsx` so classic mode preserves the current model-based routing, Agent mode calls the new Agent path, and Image Generator mode calls `generate-image` with the Gemini image model
- [ ] 5.4 Extend `src/lib/supabase/queries/messages.ts` metadata typing and chat rendering so Agent and Image Generator responses persist and display `mode`, `modelName`, thinking text, and generated image references correctly
- [ ] 5.5 Update classic model loading / resolution code so Agent-only `ai_models` entries are excluded from `fetchModels` and `resolveSelectableModels`, while Agent mode can still resolve its display name and pricing metadata server-side
- [ ] 5.6 Ensure the Agent frontend path does not call `createMessage` for the final assistant turn after the backend has already persisted it

## 6. Image Generator Mode Integration

- [ ] 6.1 Add Image Generator mode request shaping so it reuses the existing `generate-image` contract with Gemini image model, aspect ratio, resolution, and optional referenced asset URL
- [ ] 6.2 Preserve the existing placeholder, job subscription, smart placement, local-op deduplication, and `saveOp` behavior when Image Generator mode is used
- [ ] 6.3 Ensure Image Generator mode only accepts project-owned or trusted reference image URLs and surfaces failures through the current image generation error path
- [ ] 6.4 Add frontend tests covering Image Generator mode routing, placeholder lifecycle, referenced asset handling, and assistant message metadata

## 7. Verification

- [ ] 7.1 Run targeted backend and frontend tests for Agent mode, Image Generator mode, and shared Gemini image generation behavior
- [ ] 7.2 Perform an end-to-end manual verification of all three chat modes to confirm classic behavior is unchanged and the new Agent / Image Generator modes work as specified
- [ ] 7.3 Update any related OpenSpec artifacts or implementation notes if final implementation details differ from the design during execution
